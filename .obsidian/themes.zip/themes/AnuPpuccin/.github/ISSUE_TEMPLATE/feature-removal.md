---
name: Feature Removal
about: Request for removal of a theme component
title: "[Feature Removal]"
labels: Feature Removal
assignees: AnubisNekhet

---

**Feature to be removed**

**Reason for removal**

**Additional context**
Screenshots or source code inspection that proves the feature infringes on intellectual property and simply isn't an imitation
